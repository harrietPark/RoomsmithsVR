Roomsmiths / Soft wave
Extract all files together. Import soft-wave.obj with scale 1. Model coordinates are in metres.
